% fonction generation_aleatoire_courbe (pour exercice_3.m)

function [y_inf,y_sup] = generation_aleatoire_courbe(x,moyennes,ecarts_types,beta_0,gamma_0)



end
