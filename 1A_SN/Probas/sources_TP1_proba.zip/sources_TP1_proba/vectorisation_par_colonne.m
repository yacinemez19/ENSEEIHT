% Fonction vectorisation_par_colonne (exercice_1.m)

function [Vd,Vg] = vectorisation_par_colonne(I)

    % A COMPLETER

end